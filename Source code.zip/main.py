import PySimpleGUI as sg, os, shutil, sys, win32gui, win32con, time # GUI making, file renaming, file moving, closing the program, waiting
class apply_changes:
    def __init__(self):
        self.layout_apply_changes = [
                [sg.Text('Do you want to apply the changes?')],
                [sg.Text('')],
                [sg.Text('Changes log:')],
                [sg.Multiline(s=(50, 5))],
                [sg.Button('Cancel', s=(6, 1)), sg.Button('Apply', s=(6, 1))]
            ]
        self.window_apply_changes = sg.Window('Apply', layout=self.layout_apply_changes, margins=(1, 1))
        def popup():
                event, values = self.window_apply_changes.read()
                if event is None or event == sg.WIN_CLOSED or event == 'Cancel':
                    self.window_apply_changes.close()
                if event == 'Apply':
                    self.apply = True
                    self.window_apply_changes.close()
                print('Changes applied successfully.')
        popup()
class reset_game_files:
    def __init__(self):
        self.running = True
        game_path = open('Files/Exec Path', 'r+').read()
        path_from_exe = []
        self.full_path = []
        slash = '\A'.replace('A', '')
        for base, dirs, files in os.walk('Files\__GAME__'):
            for Files in files:
                path_from_exe.append((base + '/' + Files).replace(slash, '/'))
        for item in path_from_exe:
            self.full_path.append(game_path + item.split('__GAME__')[1])

        self.layout_reset_game_files = [
            [sg.Text('Do you want to reset game files to default?')],
            [sg.Text('All of the changes in game files made by the mod will be reversed.')],
            [sg.Text('Files that will be reseted:')],
            [sg.Multiline(self.full_path, s=(50, 5), disabled=True)],
            [sg.Button('Cancel', s=(6, 1)), sg.Button('Apply', s=(6, 1))]
        ]
        self.window_reset_game_files = sg.Window('Apply', layout=self.layout_reset_game_files, margins=(1, 1))

        while self.running == True:
                event, values = self.window_reset_game_files.read()
                if event is None or event == sg.WIN_CLOSED or event == 'Cancel':
                    self.window_reset_game_files.close()
                    self.running = False
                if event == 'Apply':
                    game_location_path = open('Files/Exec Path', 'r+').read()
                    files_list = []
                    num = 0
                    slash = '\A'.replace('A', '')
                    for base, dirs, files in os.walk('Files\__GAME__'):
                        for Files in files:
                            num += 1
                            files_list.append((base + '/' + Files).replace(slash, '/'))
                    for item in files_list:
                        print('-----------------------------------')
                        print('Source file:      ' + item)
                        print('Destination file: ' + game_location_path + item.split('__GAME__')[1])
                        #print('Location: ' + os.path.realpath(__file__)) getting script lacation (get working on exe)
                        shutil.copy(item, (game_location_path + item.split('__GAME__')[1]))
                    print('----------------------')
                    print('[files moved: ' + str(num) + ']')
                    print('----------------------')
                    self.running = False
                    self.window_reset_game_files.close()
class collection_editor:
    def __init__(self):
        self.afds
    def collection_editor(self):
        event, values = self.window.read()
        print(event, values)

        if event is None or event == sg.WIN_CLOSED:
            self.window.close()
            self.window.refresh()
            self.window.close_destroys_window
class Character:
    def __init__(self, name):
        # General parameters -------------------------------------------------------------------------------------------
        self.name = name
        self.eddited = ''
        # self.char_txt_file = 'Chars/' + str(self.name.upper()).replace(' ', '_') + '.TXT'# add Chats/, convert the name to string, convert the string to upper case, replace space with "_"
        game_exec_path = open('Files/Exec Path').read()
        self.game_text_file_path = str(game_exec_path) + '/STUFF/TEXT/TEXT.CSV'
        self.char_txt_file = open('Files/Exec Path', 'r+').read() + '/CHARS/MINIFIGS/' + str(
            self.name.upper()) + '/' + str(self.name.upper()) + '.TXT'
        self.char_def_txt_file_path = 'Files/Character data/' + str(self.name.upper() + '.TXT')
        self.icon_location = 'Files/Icons/' + str(self.name.upper()).replace(' ', '_') + '.png'
        self.created = True  # when this is initialized the character is created (for the edits log)
        self.name_ID = 'nameID-' + self.name
        self.minifigs_default_scale = 1
        self.minifigs_default_walk_speed = 0.5

        # Lists --------------------------------------------------------------------------------------------------------
        self.Minifigs = [
            ['Alfrid'],
            ['Armoured Dwarf Guard'],
            ['Azog (Claw)'],
            ['Balin (Lake-town)'],
            ['Balin (Young)'],
            ['Bard'],
            ['Barliman Butterbeer'],
            ['Barrow-wight'],
            ['Beorn'],
            ['Bolg'],
            ['Bombur'],
            ['Bombur (Barrel)'],
            ['Bombur (Lake-town)'],
            ['Bombur (Young)'],
            ['Braga'],
            ['Bree Peasant'],
            ['Dale Soldier'],
            ['Dori'],
            ['Dori (Lake-town)'],
            ['Dori (Young)'],
            ['Dwalin'],
            ['Dwalin (Lake-town)'],
            ['Dwalin (Young)'],
            ['Elf (Sentry)'],
            ['Elf (Worker)'],
            ['Elrond (Armoured)'],
            ['Elrond (Gown)'],
            ['Elros'],
            ['Fili'],
            ['Fili (Laketown)'],
            ['Fimbul'],
            ['Frodo'],
            ['Galadriel'],
            ['Gandalf'],
            ['Gloin'],
            ['Gloin (Lake-town)'],
            ['Goblin (Confused)'],
            ['Goblin (Scribe)'],
            ['Gollum'],
            ['Grinnah'],
            ['Gundabad Orc'],
            ['Jimli The Blacksmith'],
            ['Kili'],
            ['Kili (Lake-town)'],
            ['Lake-town Man (Archer)'],
            ['Lake-town Man (Guard)'],
            ['Legolas Greenleaf'],
            ['Lindir'],
            ['Master Of Lake-town'],
            ['Mirkwood Elf (Archer)'],
            ['Mirkwood Elf (Chief Guard)'],
            ['Mirkwood Elf (Guard)'],
            ['Narzug'],
            ['Necromancer'],
            ['Nori'],
            ['Nori (Lake-town)'],
            ['Oin'],
            ['Oin (Lake-town)'],
            ['Ori'],
            ['Ori (Lake-town)'],
            ['Percy'],
            ['Radagast'],
            ['Rosie Cotton'],
            ['Sam'],
            ['Saruman'],
            ['Sauron'],
            ['Sigrid'],
            ['Tauriel'],
            ['Tauriel (Lake-town)'],
            ['Thorin'],
            ['Thorin (Lake-town)'],
            ['Thorin (Young)'],
            ['Thrain'],
            ['Thranduil'],
            ['Thror'],
            ['Thror (Armoured)'],
            ['Tilda'],
            ['Tom Bombadil'],
            ['Witch-king'],
            ['Yazneg']
        ]  # Game characters
        self.Minifigs = [
            ['ALFRID'],
            ['AZOG'],  # AZOG, AZOGBOSS, AZOGCLAW, AZOGCLAWBOSS, MRSAZOG
            ['BABYSMAUG'],
            ['BARD'],  # BARD, BARD_LAKETOWN
            ['BARLIMANBUTTERBUR'],
            ['BARROWWIGHT'],
            ['BEORN'],
            ['BOLG'],  # BOLG, BOLGBOSS
            ['BOSS_SAURON'],
            ['BRAGA'],
            ['CITIZENS'],  # CITIZENS (22)
            ['CUSTOMCHARACTER'],
            ['DALEGHOST'],
            ['EARENDIL'],
            ['ELFGUARDCHIEF'],
            ['ELFSENTRY'],
            ['ELFWARRIOR'],
            ['ELROND'],  # ELROND, ELRONDARMOUR
            ['ELROND_GOWN'],
            ['ELROS'],
            ['FIMBUL'],
            ['GALADRIEL'],
            ['GANDALF'],
            ['GILGALAD'],
            ['GIRION'],
            ['GOBLINS'],
            # GOBLIN_A, GOBLIN_B, GOBLIN_C, GOBLIN_FRIENDLY, GOBLINFEMALE_A, GOBLINFEMALE_B, GOBLINMALE_A, GOBLINMALE_B
            ['GRINNAH'],
            ['GUNDABADORC'],  # GUNDABADORC, GUNDABADORC_TARGET, ORCFEMALE_A, ORCFEMALE_B, ORCMALE_A
            ['LAKETOWNSOLDIER'],  # DALESOLDIER, LAKETOWNSOLDIER, LAKETOWNSOLDIERARCHER
            ['LEGOLAS'],
            ['LINDIR'],
            ['MASTEROFLAKETOWN'],
            ['MINIFIG_SKELETON'],
            ['MIRKWOOD'],  # MIRKWOODELFARCHERB, MIRKWOODELFCHIEF, MIRKWOODELFGUARD
            ['MORIAORC'],
            ['NARZUG'],
            ['NECROMANCER'],
            ['OLDBELLRINGER'],
            ['ORCS'],  # ORCMALE_SHIELDED, ORCMALE_ARCHER, ORCMALE_MELEE, TRACKERORC
            ['PERCY'],
            ['PETERJACKSONBREE'],
            ['QUEST'],
            ['RADAGAST'],
            ['RIVENDELLFEMALE_B'],
            ['SARUMAN'],
            ['SAURON'],
            ['SHAREDANIMS'],  # ANIMATIONS FOR WEPONS
            ['SIGRID'],
            ['SIRCHRISTOPHERLEE'],
            ['SKELETON'],
            ['SUPER_CHARACTERS'],  # TEXTURES
            ['TAURIEL'],  # TAURIEL, TAURIEL_LAKETOWN
            ['THRANDUIL'],
            ['TOMBOMBADIL'],
            ['WITCHKING'],
            ['WIZARDS'],  # WIZARDA, WIZARDB
            ['YAZNEG']
        ]  # Folder names

        self.Char_Items = ['Character item 1', 'Character item 2', 'Character item 3']
        self.Game_Items = ['Game item 1', 'Game item 2', 'Game item 3', 'Game item 4', 'Game item 5', 'Game item 6']

        Dwarfs = ['Armoured Dwarf Guard', 'Balin', 'Balin (Lake-town)', 'Balin (Young)', 'Bard', 'Bifur',
                  'Bifur (Lake-town)', 'Bofur', 'Bofur (Lake-town)', 'Bombur', 'Bombur (Barrel)', 'Bombur (Lake-town)',
                  'Bombur (Young)', 'Dori', 'Dori (Lake-town)', 'Dori (Young)', 'Dwalin', 'Dwalin (Lake-town)',
                  'Dwalin (Young)', 'Fili', 'Fili (Laketown)', 'Glòín', 'Glóín (Lake-town)', 'Jímlí The Blacksmith',
                  'Kili', 'Kili (Lake-town)', 'Nori', 'Nori (Lake-town)', 'Òín', 'Óin (Lake-town)', 'Ori',
                  'Ori (Lake-town)', 'Thorin', 'Thorin (Lake-town)', 'Thorin (Young)', 'Thràín', 'Thrór',
                  'Thrór (Armoured)']
        Elfs = ['Elf (Sentry)', 'Elf (Worker)', 'Elrond (Armoured)', 'Elrond (Gown)', 'Elros', 'Galadriel',
                'Legolas Greenleaf', 'Lindir', 'Mirkwood Elf (Archer)', 'Mirkwood Elf (Chief Guard)',
                'Mirkwood Elf (Guard)', 'Tauriel', 'Tauriel (Lake-town)', 'Thranduil']
        Goblins = ['Goblin (Confused)', 'Goblin (Scribe)', 'Grinnah', 'Great Goblin', 'Golin Brute']
        Hobbits = ['Bilbo', 'Bilbo (Hobbiton)', 'Bilbo (Lake-town)', 'Bilbo (Old)', 'Frodo', 'Rosie Cotton', 'Sam']
        Humans = ['Alfrid', 'Baín', 'Bard', 'Barliman Butterbeer', 'Braga', 'Lake-town Man (Archer)',
                  'Lake-town Man (Guard)', 'Master Of Lake-town', 'Percy', 'Sígríd', 'Tílda']
        Orcs = ['Bolg', 'Gundabad Orc', 'Narzug', 'Orc Berserker']
        Trolls = ['Bert', 'Tom', 'William', 'Mrs Troll', 'Troll Bouncer']
        Wizzards = ['Gandalf', 'Radagast', 'Saruman']
        Other = ['Barrow-wight', 'Gollum', 'Necromancer', 'Sauron', 'Tom Bombadil', 'Witch-king']

        DLC1 = ['Lady Dwarf', 'Saruman (Day Off)', 'Thranduil’s Elk', 'Dwarf Soldier', 'Girion',
                'River Troll']  # Side Quest Character Pack
        DLC2 = ['Snow Troll', 'Spider', 'Stone Dwarf', 'Bandobras “Bullroarer” Took', 'Baby Smaug',
                'Baby Gimli']  # The Big Little Character Pack

        # Getting INDEX ------------------------------------------------------------------------------------------------
        def get_index(self):
            # Empty index variables for stuff that may not be in text file (to not cause any errors)
            # Items
            self.Goblin_Dagger_index = 'none'

            # Abilities
            self.ability_flying_index = 'none'

            # General character stable settings ------------------------------------------------------------------------
            with open(self.char_txt_file) as myFile:
                # General Settings
                for num, line in enumerate(myFile):
                    if 'icon_override' in line:
                        self.icon_index = num
                    if 'name' in line:
                        self.name_index = num
                    if '// name_color=' in line:
                        self.name_color_index = num
                    if 'scale' in line:
                        self.scale_index = num
                    if 'tiptoe_speed' in line:
                        self.tiptoe_speed_index = num
                    if 'walk_speed' in line:
                        self.walk_speed_index = num
                    if 'run_speed' in line:
                        self.run_speed_index = num
                    if 'sprint_speed' in line:
                        self.sprint_speed_index = num
                    if 'jump_speed' in line:
                        self.jump_speed_index = num
                    if 'air_gravity' in line:
                        self.air_gravity_index = num
                    if 'acceleration' in line:
                        self.acceleration_index = num
                    if 'turn_rate' in line:
                        self.turn_rate_index = num
                    if 'max_aim_targets' in line:
                        self.max_aim_targets_index = num

                    # Headers
                    if '// Abilities' in line:
                        self.abilities_index = num

                    # Items
                    if 'default_item "Goblin_Dagger"' in line:
                        self.Goblin_Dagger_index = num

                    # Abilities
                    if 'ability "Flying"' in line:
                        self.ability_flying_index = num
                        print('Ability flying in text file index: ' + str(self.ability_flying_index))

                    # Custom
                    if '// custom_name=' in line:
                        self.custom_name_index = num
            myFile.close()

        get_index(self)  # In a function so you can refresh the indexes

        def get_def_index(self):
            # Empty index variables for stuff that may not be in text file (to not cause any errors)
            # Items
            self.Goblin_Dagger_index_def = 'none'

            # Abilities
            self.ability_flying_index_def = 'none'

            # General character stable settings ------------------------------------------------------------------------
            with open(self.char_def_txt_file_path) as myFile:
                # General Settings
                for num, line in enumerate(myFile):
                    if 'icon_override' in line:
                        self.icon_index_def = num
                    if 'name' in line:
                        self.name_index_def = num
                    if '// name_color=' in line:
                        self.name_color_index_def = num
                    if 'scale' in line:
                        self.scale_index_def = num
                    if 'tiptoe_speed' in line:
                        self.tiptoe_speed_index_def = num
                    if 'walk_speed' in line:
                        self.walk_speed_index_def = num
                    if 'run_speed' in line:
                        self.run_speed_index_def = num
                    if 'sprint_speed' in line:
                        self.sprint_speed_index_def = num
                    if 'jump_speed' in line:
                        self.jump_speed_index_def = num
                    if 'air_gravity' in line:
                        self.air_gravity_index_def = num
                    if 'acceleration' in line:
                        self.acceleration_index_def = num
                    if 'turn_rate' in line:
                        self.turn_rate_index_def = num
                    if 'max_aim_targets' in line:
                        self.max_aim_targets_index_def = num

                    # Headers
                    if '// Abilities' in line:
                        self.abilities_index_def = num

                    # Items
                    if 'default_item "Goblin_Dagger"' in line:
                        self.Goblin_Dagger_index_def = num

                    # Abilities
                    if 'ability "Flying"' in line:
                        self.ability_flying_index_def = num

                    # Custom
                    if '// name_color=' in line:
                        self.name_color_index_def = num
            myFile.close()

        get_def_index(self)

        # Getting VALUES - by reading text files and using Indexes (pure values) --------------------------------------
        def get_values(self):
            self.char_txt_file_read = open(self.char_txt_file).readlines()  # File content as .readlines
            for position, line in enumerate(self.char_txt_file_read):  # Iterate over each line and its index
                if position in [self.icon_index]:
                    self.icon_value = line.replace('icon_override ', "")
                if position in [self.name_index]:
                    self.name_value = line.replace('name ', "")
                if position in [self.name_color_index]:
                    self.name_color_value = line.replace('// name_color=', "").replace('\n', "")  # Fixed an error
                if position in [self.scale_index]:
                    self.scale_value = line.replace('scale=', "")
                if position in [self.tiptoe_speed_index]:
                    self.tiptoe_speed_value = line.replace('tiptoe_speed=', "")
                if position in [self.walk_speed_index]:
                    self.walk_speed_value = line.replace('walk_speed=', "")

                # Headers Values
                if position in [self.abilities_index]:
                    self.abilities_value = line
                # Custom Values
                if position in [self.custom_name_index]:
                    self.custom_name_value = line.replace('// custom_name=', "")

            # Ability values (True/False)
            if self.ability_flying_index == 'none':  # If flying ability has no index it does not exist
                self.ability_flying = False
            if self.ability_flying_index != 'none':  # If  flying ability index exists then the character has this ability
                self.ability_flying = True

        get_values(self)  # In a function so you can refresh the values

        def get_def_values(self):
            for position, line in enumerate(
                    open(self.char_def_txt_file_path).readlines()):  # Iterate over each line and its index
                if position in [self.icon_index]:
                    self.icon_value_def = line.replace('icon_override ', "")
                if position in [self.name_index]:
                    self.name_value_def = line.replace('name ', "")
                if position in [self.name_color_index]:
                    self.name_color_value_def = line.replace('// name_color=', "").replace('\n', "")  # Fixed an error
                if position in [self.scale_index]:
                    self.scale_value_def = line.replace('scale=', "")
                if position in [self.tiptoe_speed_index]:
                    self.tiptoe_speed_value_def = line.replace('tiptoe_speed=', "")
                if position in [self.walk_speed_index]:
                    self.walk_speed_value_def = line.replace('walk_speed=', "")

                # Headers Values
                if position in [self.abilities_index]:
                    self.abilities_value_def = line
                # Custom Values
                if position in [self.custom_name_index]:
                    self.custom_name_value_def = line.replace('// custom_name=', "")
            # Ability values (True/False)
            if self.ability_flying_index == 'none':  # If flying ability has no index it does not exist
                self.ability_flying_def = False
            if self.ability_flying_index != 'none':  # If  flying ability index exists then ability exists
                self.ability_flying_def = True

        get_def_values(self)

        # Creating Keys (PySimpleGui) ----------------------------------------------------------------------------------
        def create_keys(self):
            self.name_key = 'key-' + self.name + '-name'
            self.name_input_key = 'key-' + self.name + '-name-input'
            self.icon_key = 'key-' + self.name + '-icon'

            self.scale_input_key = 'key-' + self.name + '-scale_input'
            self.scale_button_key = 'key-' + self.name + '-scale_button'
            self.scale_slider_key = 'key-' + self.name + '-scale_slider'

            self.walk_speed_input_key = 'key-' + self.name + '-walk_speed_input'
            self.walk_speed_button_key = 'key-' + self.name + '-walk_speed_button'
            self.walk_speed_slider_key = 'key-' + self.name + '-walk_speed_slider'

            self.godmode_key = 'key-' + self.name + '-godmode'
            self.flying_key = 'key-' + self.name + '-flying'

            self.char_items_key = 'key-' + self.name + '-char_items'
            self.game_items_key = 'key-' + self.name + '-game_items'

            self.tiptoe_speed_key = 'key-' + self.name + '-tiptoe_speed'
            self.run_speed_key = ''
            self.sprint_speed_key = ''
            self.jump_speed_key = ''
            self.air_gravity_key = ''
            self.turn_rate_key = ''
            self.max_aim_targets_key = ''

            self.apply_changes_key = 'key-' + self.name + '-apply_changes'
            self.cancel_key = 'key-' + self.name + '-cancel'

        create_keys(self)  # To clean thing up

        # Categorise Characters ----------------------------------------------------------------------------------------
        def categorise_chars(self):
            if self.name in Dwarfs:
                self.type = 'Dwarfs'
            elif self.name in Elfs:
                self.type = 'Elfs'
            elif self.name in Goblins:
                self.type = 'Goblins'
            elif self.name in Hobbits:
                self.type = 'Hobbits'
            elif self.name in Humans:
                self.type = 'Humans'
            elif self.name in Orcs:
                self.type = 'Orcs'
            elif self.name in Trolls:
                self.type = 'Trolls'
            elif self.name in Wizzards:
                self.type = 'Wizzards'
            elif self.name in Other:
                self.type = 'Other'
            elif self.name in DLC1:
                self.type = 'DLC1'
            elif self.name in DLC2:
                self.type = 'DLC2'
            else:
                self.type = 'Unknown'

        categorise_chars(self)

        # End of initializing the character
        print('[LOAD] ---> ' + self.name)
        print('[Alfrid] - Category:     ' + self.type)
        print('[Alfrid] - Name color:   ' + self.name_color_value)
        print('[Alfrid] - Custom name:  ' + self.custom_name_value)

    def char_editor(self):
        layout_char_editor_bar = [
            ['Options', ['Options', 'New Character', 'Browse']]
        ]
        layout_char_editor = [
            [sg.Menu(layout_char_editor_bar)],
            [sg.HorizontalSeparator()],
            [sg.Text('', size=(5, 0)), sg.Text(self.name, size=(10, 0), font=('Alias', 20))],
            [sg.Text('', size=(5, 0)), sg.Image(filename=self.icon_location), sg.Text('', size=(5, 0))],
            [sg.Text('', size=(31, 0))],  # SISER
            [sg.HorizontalSeparator()],
            # SCALE
            [sg.Text('Scale:', font=1, s=(16, 0)),
             sg.Spin([i for i in range(0, 100)], initial_value=self.scale_value, s=(5, 1), key=self.scale_input_key,
                     enable_events=True), sg.Button('    ', key=self.scale_button_key)],
            [sg.Slider(orientation='h', border_width=1, enable_events=True, size=(27, 20), range=(0, 100),
                       resolution=0.1, default_value=self.scale_value, key=self.scale_slider_key)],
            [sg.Text('', size=(0, 0))],
            # WALK SPEED
            [sg.Text('Walk Speed:', font=1, s=(16, 0)),
             sg.Spin([i for i in range(0, 100)], initial_value=self.walk_speed_value, s=(5, 1),
                     key=self.walk_speed_input_key, enable_events=True),
             sg.Button('    ', key=self.walk_speed_button_key)],
            [sg.Slider(orientation='h', border_width=1, enable_events=True, size=(27, 20), range=(0, 100),
                       resolution=0.1, default_value=self.walk_speed_value, key=self.walk_speed_slider_key)],
            [sg.Text('', size=(0, 0))],
            # CHECKBOXES
            [sg.Checkbox('Godmode', k='key-test-234'),
             sg.Checkbox('Flying', key=self.flying_key, enable_events=True, default=self.ability_flying)],
            # ITEMS
            [sg.Text('Character Default Items:'), sg.Text('', size=(1, 0)), sg.Button('Item List', s=(7, 0))],
            [sg.Listbox(self.Char_Items, s=(32, 5), enable_events=True, k=self.char_items_key)],
            [sg.Text('Add items:', s=(9, 1)), sg.Input(s=(22, 1), enable_events=True)],  # 'Search 🔍'
            [sg.Listbox(self.Game_Items, s=(32, 3), enable_events=True, k=self.game_items_key)],
            # OPTIONS
            [sg.Text('', size=(0, 0))],
            [sg.Button('Cancel', size=(10, 0), k=self.cancel_key), sg.Text('', size=(5, 0)),
             sg.Button('Ok', size=(10, 0), k=self.apply_changes_key)],
            # ADVANCED -------------------------------------------------------------------------------------------------
            [sg.Text('', size=(0, 0))],
            [sg.HorizontalSeparator()],
            [sg.Text('', size=(5, 0)), sg.Text('Advanced', size=(10, 0), font=('Alias', 20))],
            [sg.Text('', size=(0, 0))],
            # NAME
            [sg.Text('Name:', s=(6, 1)), sg.Input(self.custom_name_value, size=(25, 0), k=self.name_input_key,
                                                  background_color=self.name_color_value, text_color='black')],
            [sg.Text('Name color:', s=(10, 1)),
             sg.Button('', size=(1, 0), button_color=('white', ('#FFFFFF')), k='WHITE'),
             sg.Button('', size=(1, 0), button_color=('white', ('#000000')), k='BLACK'),
             sg.Button('', size=(1, 0), button_color=('white', ('#cc0000')), k='RED'),
             sg.Button('', size=(1, 0), button_color=('white', ('#8fce00')), k='GREEN'),
             sg.Button('', size=(1, 0), button_color=('white', ('#2986cc')), k='BLUE'),
             sg.Button('', size=(1, 0), button_color=('white', ('#ffd966')), k='YELLOW')],  # COLORED BUTTONS
            # ICON
            [sg.Text('Icon', size=(9, 1), font=('Alias', 15)), sg.Image(filename=self.icon_location)],
            [sg.Text('Change the icon:'), sg.FileBrowse('Browse Files (.tex)', s=(15, 1))],
        ]
        char_editor = [
            [sg.Column(layout_char_editor, scrollable=True, vertical_scroll_only=True)],
        ]  # Add Scroll Bar
        self.window = sg.Window('LEGO - The Hobbit', layout=char_editor, margins=(1, 1))

    def char_editor_buttons(self):
        event, values = self.window.read()
        print(event, values)

        if event is None or event == sg.WIN_CLOSED:
            self.window.close()
            self.window.refresh()
            self.window.close_destroys_window

        if event == self.scale_input_key:
            self.window.Element(self.scale_slider_key).Update(values[self.scale_input_key])
            self.scale_value = str(values[self.scale_input_key])
        if event == self.scale_button_key:
            self.window.Element(self.scale_slider_key).Update(self.scale_value_def)
            self.window.Element(self.scale_input_key).Update(self.scale_value_def)
            self.scale_value = str(self.scale_value_def)
        if event == self.scale_slider_key:
            self.window.Element(self.scale_input_key).Update(values[self.scale_slider_key])
            self.scale_value = str(values[self.scale_slider_key])

        if event == self.walk_speed_input_key:
            self.window.Element(self.walk_speed_slider_key).Update(values[self.walk_speed_input_key])
            self.walk_speed_value = str(values[self.walk_speed_input_key])
        if event == self.walk_speed_button_key:
            self.window.Element(self.walk_speed_slider_key).Update(self.minifigs_default_walk_speed)
            self.window.Element(self.walk_speed_input_key).Update(self.minifigs_default_walk_speed)
            self.walk_speed_value = self.walk_speed_value_def
        if event == self.walk_speed_slider_key:
            self.window.Element(self.walk_speed_input_key).Update(values[self.walk_speed_slider_key])
            self.walk_speed_value = str(values[self.walk_speed_slider_key])

        if event == 'WHITE':
            self.name_color_value = 'white'
            self.window[self.name_input_key].update(background_color='white')
            self.window[self.name_input_key].update(text_color='black')
            print('Set name color to white')
        if event == 'BLACK':
            self.name_color_value = 'black'
            self.window[self.name_input_key].update(background_color='black')
            self.window[self.name_input_key].update(text_color='white')
            print('Set name color to black')
        if event == 'RED':
            self.name_color_value = 'red'
            self.window[self.name_input_key].update(background_color='red')
            self.window[self.name_input_key].update(text_color='black')
            print('Set name color to red')
        if event == 'GREEN':
            self.name_color_value = 'green'
            self.window[self.name_input_key].update(background_color='green')
            self.window[self.name_input_key].update(text_color='black')
            print('Set name color to green')
        if event == 'BLUE':
            self.name_color_value = 'blue'
            self.window[self.name_input_key].update(background_color='blue')
            self.window[self.name_input_key].update(text_color='black')
            print('Set name color to blue')
        if event == 'YELLOW':
            self.name_color_value = 'yellow'
            self.window[self.name_input_key].update(background_color='yellow')
            self.window[self.name_input_key].update(text_color='black')
            print('Set name color to yellow')

        if event == self.apply_changes_key:
            print(self.scale_value + self.scale_value_def)
            # Open character text file
            lines = open(self.char_txt_file, 'r').readlines()
            print('[APPLY CHANGES] ---> ' + self.name)
            # Set SCALE
            if self.scale_value != self.scale_value_def:
                lines[self.scale_index] = 'scale=' + str(values[self.scale_slider_key]) + '\n'
                print('[SCALE] ---> ' + self.scale_value)
            # Set WALK SPEED
            if self.walk_speed_value != self.walk_speed_value_def:
                lines[self.walk_speed_index] = 'walk_speed=' + str(values[self.walk_speed_slider_key]) + '\n'
                print('[WALK SPEED] ---> ' + self.walk_speed_value)
            # Set FLYING ABILITY
            if (self.window.Element(self.flying_key).get()) == False:  # If Flying is turned off in GUI
                if self.ability_flying_index != 'none':  # And if the ability is in the text file
                    lines[self.ability_flying_index] = ''  # Then set that line to empty
                    print('[REMOVED ABILITY] ---> Flying')
            '''
            if (self.window.Element(self.flying_key).get()) == True: # If Flying is turned on in GUI
                if self.ability_flying_index == 'none':              # If there is no ability in text file
                    lines[self.abilities_index] = self.abilities_value + '\n' + 'ability "Flying"\n'# make one!
                    print('[ADDED ABILITY] ---> Flying')
            '''
            # Set CUSTOM NAME COLOR
            if self.name_color_value != self.name_color_value_def:
                print('Color is changed')
                print(self.name_color_value)

            # Set CUSTOM NAME
            '''
            if self.name_color_value != self.name_color_value_def: # If name or color are changed
                print('Custom name input box value is diffrent than char name def value, or color of name is diffrent than char def color name')
                print('==============================')
                print(self.name_color_value)
                print(self.name_color_value_def)
                print(values[str(self.name_input_key).replace('\n', '')])
                print(str(self.name).replace('\n', ''))
                print('==============================')

            lines[self.name_index] = 'name ' + self.name_ID + '\n'

            print(self.name_index)
            if self.name_color_value == 'white':
                lines[self.name_color_index] = '// custom_name_color=white\n'
                open(self.game_text_file_path, 'a').write('\n"' + self.name_ID + '","All","Char","' + values[self.name_input_key] + '"\n')
                print('Changed ' + self.name + ' color to white')
            if self.name_color_value == 'black':
                lines[self.name_color_index] = '// custom_name_color=black\n'
                open(self.self.game_text_file_path, 'a').write('\n"' + self.name_ID + '","All","Char","' + values[self.name_input_key] + '"\n')
                print('Changed ' + self.name + ' color to black')
            if self.name_color_value == 'red':
                lines[self.name_color_index] = '// custom_name_color=red\n'
                open(self.game_text_file_path, 'a').write('\n"' + self.name_ID + '","All","Char","~1' + values[self.name_input_key] + '~~"\n')
            if self.name_color_value == 'green':
                lines[self.name_color_index] = '// custom_name_color=green\n'
                open(self.game_text_file_path, 'a').write('\n"' + self.name_ID + '","All","Char","~2' + values[self.name_input_key] + '~~"\n')
            if self.name_color_value == 'blue':
                lines[self.name_color_index] = '// custom_name_color=blue\n'
                open(self.game_text_file_path, 'a').write('\n"' + self.name_ID + '","All","Char","~3' + values[self.name_input_key] + '~~"\n')
            if self.name_color_value == 'yellow':
                lines[self.name_color_index] = '// custom_name_color=yellow\n'
                open(self.game_text_file_path, 'a').write('\n"' + self.name_ID + '","All","Char","~6' + values[self.name_input_key] + '~~"\n')
            # Set CUSTOM NAME VALUE
            lines[self.custom_name_index] = '// custom_name=' + values[self.name_input_key] + '\n'
            '''
            # Save the file
            out = open(self.char_txt_file, 'w')
            out.writelines(lines)
            out.close()

            # Refresh options index and values
            def get_index(self):
                # Empty index variables for stuff that may not be in text file (to not cause any errors)
                # Items
                self.Goblin_Dagger_index = 'none'

                # Abilities
                self.ability_flying_index = 'none'

                # General character stable settings --------------------------------------------------------------------
                with open(self.char_txt_file) as myFile:
                    # General Settings
                    for num, line in enumerate(myFile):
                        if 'icon_override' in line:
                            self.icon_index = num
                        if 'name' in line:
                            self.name_index = num
                        if '// name_color=' in line:
                            self.name_color_index = num
                        if 'scale' in line:
                            self.scale_index = num
                        if 'tiptoe_speed' in line:
                            self.tiptoe_speed_index = num
                        if 'walk_speed' in line:
                            self.walk_speed_index = num
                        if 'run_speed' in line:
                            self.run_speed_index = num
                        if 'sprint_speed' in line:
                            self.sprint_speed_index = num
                        if 'jump_speed' in line:
                            self.jump_speed_index = num
                        if 'air_gravity' in line:
                            self.air_gravity_index = num
                        if 'acceleration' in line:
                            self.acceleration_index = num
                        if 'turn_rate' in line:
                            self.turn_rate_index = num
                        if 'max_aim_targets' in line:
                            self.max_aim_targets_index = num

                        # Headers
                        if '// Abilities' in line:
                            self.abilities_index = num

                        # Items
                        if 'default_item "Goblin_Dagger"' in line:
                            self.Goblin_Dagger_index = num

                        # Abilities
                        if 'ability "Flying"' in line:
                            self.ability_flying_index = num
                            print('Ability flying in text file index: ' + str(self.ability_flying_index))

                        # Custom
                        if '// custom_name=' in line:
                            self.custom_name_index = num
                myFile.close()

            get_index(self)

            def get_values(self):
                self.char_txt_file_read = open(self.char_txt_file).readlines()  # File content as .readlines
                for position, line in enumerate(self.char_txt_file_read):  # Iterate over each line and its index
                    if position in [self.icon_index]:
                        self.icon_value = line.replace('icon_override ', "")
                    if position in [self.name_index]:
                        self.name_value = line.replace('name ', "")
                    if position in [self.name_color_index]:
                        self.name_color_value = line.replace('// name_color=', "").replace('\n', "")  # Fixed an error
                    if position in [self.scale_index]:
                        self.scale_value = line.replace('scale=', "")
                    if position in [self.tiptoe_speed_index]:
                        self.tiptoe_speed_value = line.replace('tiptoe_speed=', "")
                    if position in [self.walk_speed_index]:
                        self.walk_speed_value = line.replace('walk_speed=', "")

                    # Headers Values
                    if position in [self.abilities_index]:
                        self.abilities_value = line
                    # Custom Values
                    if position in [self.custom_name_index]:
                        self.custom_name_value = line.replace('// custom_name=', "")

                # Ability values (True/False)
                if self.ability_flying_index == 'none':  # If flying ability has no index it does not exist
                    self.ability_flying = False
                if self.ability_flying_index != 'none':  # If  flying ability index exists then the character has this ability
                    self.ability_flying = True

            get_values(self)

            # Make a popup
            sg.popup(self.name + ' edits saved!', keep_on_top=True)
class set_usare_game_path:
    def __init__(self):
        self.layout_popup = [
                [sg.Text('To run the mod, first select the folder in witch the game exec is located.')],
                [sg.Text('(Probably named "LEGO - The Hobbit" )')],
                # [sg.InputText(size=(44, 1)), sg.FileBrowse(key="-IN-", change_submits=True, file_types=(("LEGOHobbit.exe", "*.exe"),))], # For seleceting the .exe
                [sg.InputText(size=(50, 1), k='Input'), sg.FolderBrowse(key="FolderBrowse", change_submits=True)],
                [sg.Text()],
                [sg.Button('Exit', s=(6, 1)), sg.Button('Ok', s=(6, 1))]
            ]
        self.window_popup = sg.Window('Gate', layout=self.layout_popup, margins=(1, 1))
    def buttons(self):
        event, values = self.window_popup()
        if event is None or event == sg.WIN_CLOSED or event == 'Exit':
            sys.exit()
            dududu = "anything so i can close this thing"
        if event == 'Ok' and values['Input'] != '':
            # Actual writing to file is here
            if os.path.exists(values['Input']) == True:
                file = open('Files/Exec Path', 'w')
                file.write(values['Input'])
                file.close()
                self.window_popup.close()
            # "Ups!" Popup
            if os.path.exists(values['Input']) == False:
                    sg.popup('Ups! It seems like this path does not exist.\n\n' + values['Input'])
                    print('Incorrect path!: ' + values['Input'])   # When getting the game path from user

sg.theme('BrownBlue')

# Path checker
game_location_path = open('Files/Exec Path', 'r+').read()

window = set_usare_game_path() # Create a window only once
while game_location_path == '':
    window.buttons() # Place only the buttons in the loop
    game_location_path = open('Files/Exec Path', 'r+').read()
    print('ending set game location path loop')

# General Parameters/Settings/Lists ------------------------------------------------------------------------------------
game_location_path = open('Files/Exec Path', 'r+').read()
cutscene_folder = game_location_path + '/CUT/LOADING_SCREEN_STARTUP/'
main_window_state = False

# Functions
def edits_list_load():
    global Edits_list
    Edits_list_file = open('Files/Edits list.txt', 'r')
    Edits_list = Edits_list_file.read()
    Edits_list_file.close()
def cutscene_cut(parameter):
    global cutscene_off
    game_location_path = open('Files/Exec Path', 'r+').read()
    good_name = str(game_location_path) + '/CUT/LOADING_SCREEN_STARTUP/LOADING_SCREEN_STARTUP.TXT'
    bad_name = str(game_location_path) + '/CUT/LOADING_SCREEN_STARTUP/LOADING_SCREEN_STARTUP[TURNED OFF].TXT'
    if game_location_path == '':
        short_cutscene_option = True
        # we don't actually know (probably the checkbox will be off because it's the first run)
    if game_location_path != '':
        if parameter == 'off' and os.path.isfile(good_name):
            os.rename(good_name, bad_name)
        if parameter == 'on' and os.path.isfile(bad_name):
            os.rename(bad_name, good_name)
        if parameter == 'status_check':
            if os.path.isfile(good_name):
                cutscene_off = False # False because the bool is for a checkbox
            if os.path.isfile(bad_name):
                cutscene_off = True # Same as above
def check_COLLECTION_state():
    global collection_unlocked
    game_location_path = open('Files/Exec Path', 'r+').read()
    collection_path = game_location_path + '/CHARS/COLLECTION.TXT'
    collection_values = open(collection_path, 'r').readlines()
    # Get index
    with open(game_location_path + '/CHARS/COLLECTION.TXT') as COLLECTION:
        for num, line in enumerate(COLLECTION):
            if '// STATE=' in line:
                state_index = num
    # Get value
    for position, line in enumerate(collection_values):  # Iterate over each line and its index
        if position in [state_index]:
            state_value = line.replace('// STATE=', "")

    if state_value == 'UNLOCKED\n':
        collection_unlocked = True
    if state_value == 'DEFAULT\n':
        collection_unlocked = False
edits_list_load()
check_COLLECTION_state()

# Usless?
def chk_win_state():
    global main_window_state, popup_state, main_window_buttons
    game_location_path = open('Files/Exec Path', 'r+').read()
    if game_location_path == '':
        main_window_state = False
        popup_state = True
    if game_location_path != '':
        main_window_state = True
        popup_state = False
def unlock_every_character():
    print()
    print()
chk_win_state()

cutscene_cut('status_check') # Using a function to check the status of this setting, for main window layout GUI

# Lists ----------------------------------------------------------------------------------------------------------------
characters1 = [
    ['Thorin (Young)'],
    ['Thràín'],
    ['Balin (Young)'],
    ['Thrór'],
    ['Armoured Dwarf Guard'],
    ['Frodo'],
    ['Sam'],
    ['Bilbo (Hobbiton)'],
    ['Bilbo'],
    ['Gandalf'],
    ['Balin'],
    ['Bifur'],
    ['Bofur'],
    ['Bombur'],
    ['Dori'],
    ['Dwalin'],
    ['Fili'],
    ['Kili'],
    ['Gloin'],
    ['Nori'],
    ['Oin'],
    ['Ori'],
    ['Thorin']
]
characters2 = ['Alfrid', 'Armoured Dwarf Guard', 'Azog (Claw)', 'Baín', 'Balin', 'Balin (Lake-town)', 'Balin (Young)', 'Bard', 'Barliman Butterbeer', 'Barrow-wight', 'Beorn', 'Bifur', 'Bifur (Lake-town)', 'Bilbo', 'Bilbo (Hobbiton)', 'Bilbo (Lake-town)', 'Bilbo (Old)', 'Bofur', 'Bofur (Lake-town)', 'Bolg', 'Bombur', 'Bombur (Barrel)', 'Bombur (Lake-town)', 'Bombur (Young)', 'Braga', 'Bree Peasant', 'Dale Soldier', 'Dori', 'Dori (Lake-town)', 'Dori (Young)', 'Dwalin', 'Dwalin (Lake-town)', 'Dwalin (Young)', 'Elf (Sentry)', 'Elf (Worker)', 'Elrond (Armoured)', 'Elrond (Gown)', 'Elros', 'Fili', 'Fili (Laketown)', 'Fímbul', 'Frodo', 'Galadriel', 'Gandalf', 'Glòín', 'Glóín (Lake-town)', 'Goblin (Confused)', 'Goblin (Scribe)', 'Gollum', 'Grinnah', 'Gundabad Orc', 'Jímlí The Blacksmith', 'Kili', 'Kili (Lake-town)', 'Lake-town Man (Archer)', 'Lake-town Man (Guard)', 'Legolas Greenleaf', 'Lindir', 'Master Of Lake-town', 'Mirkwood Elf (Archer)', 'Mirkwood Elf (Chief Guard)', 'Mirkwood Elf (Guard)', 'Narzug', 'Necromancer', 'Nori', 'Nori (Lake-town)', 'Òín', 'Ori', 'Ori (Lake-town)', 'Óin (Lake-town)', 'Percy', 'Radagast', 'Rosie Cotton', 'Sam', 'Saruman', 'Sauron', 'Sígríd', 'Tauriel', 'Tauriel (Lake-town)', 'Thorin', 'Thorin (Lake-town)', 'Thorin (Young)', 'Thràín', 'Thranduil', 'Thrór', 'Thrór (Armoured)', 'Tílda', 'Tom Bombadil', 'Witch-king', 'Yazneg']

Dwarfs = ['Armoured Dwarf Guard', 'Balin', 'Balin (Lake-town)', 'Balin (Young)', 'Bard', 'Bifur', 'Bifur (Lake-town)', 'Bofur', 'Bofur (Lake-town)', 'Bombur', 'Bombur (Barrel)', 'Bombur (Lake-town)', 'Bombur (Young)', 'Dori', 'Dori (Lake-town)', 'Dori (Young)', 'Dwalin', 'Dwalin (Lake-town)', 'Dwalin (Young)', 'Fili', 'Fili (Laketown)', 'Glòín', 'Glóín (Lake-town)', 'Jímlí The Blacksmith', 'Kili', 'Kili (Lake-town)', 'Nori', 'Nori (Lake-town)', 'Òín', 'Óin (Lake-town)', 'Ori', 'Ori (Lake-town)', 'Thorin', 'Thorin (Lake-town)', 'Thorin (Young)', 'Thràín', 'Thrór', 'Thrór (Armoured)']
Elfs = ['Elf (Sentry)', 'Elf (Worker)', 'Elrond (Armoured)', 'Elrond (Gown)', 'Elros', 'Galadriel', 'Legolas Greenleaf', 'Lindir', 'Mirkwood Elf (Archer)', 'Mirkwood Elf (Chief Guard)', 'Mirkwood Elf (Guard)', 'Tauriel', 'Tauriel (Lake-town)', 'Thranduil']
Goblins = ['Goblin (Confused)', 'Goblin (Scribe)', 'Grinnah', 'Great Goblin', 'Golin Brute']
Hobbits = ['Bilbo', 'Bilbo (Hobbiton)', 'Bilbo (Lake-town)', 'Bilbo (Old)', 'Frodo', 'Rosie Cotton', 'Sam']
Humans = ['Alfrid', 'Baín', 'Bard', 'Barliman Butterbeer', 'Braga', 'Lake-town Man (Archer)', 'Lake-town Man (Guard)', 'Master Of Lake-town', 'Percy', 'Sígríd', 'Tílda']
Orcs = ['Bolg', 'Gundabad Orc', 'Narzug', 'Orc Berserker']
Trolls = ['Bert', 'Tom', 'William', 'Mrs Troll', 'Troll Bouncer']
Wizzards = ['Gandalf', 'Radagast', 'Saruman']
Other = ['Barrow-wight', 'Gollum', 'Necromancer', 'Sauron', 'Tom Bombadil', 'Witch-king']

DLC1 = ['Lady Dwarf', 'Saruman (Day Off)', 'Thranduil’s Elk', 'Dwarf Soldier', 'Girion', 'River Troll'] # Side Quest Character Pack
DLC2 = ['Snow Troll', 'Spider', 'Stone Dwarf', 'Bandobras “Bullroarer” Took', 'Baby Smaug', 'Baby Gimli'] # The Big Little Character Pack

# Layouts --------------------------------------------------------------------------------------------------------------
layout_main_bar = [
    ['Main', ['Text 1', 'Text 1', 'Text 3']],
    ['Characters', ['Create a new character', 'Edit game characters', ['Dwarfs', [Dwarfs], 'Elfs', [Elfs], 'Goblins',[Goblins], 'Hobbits', [Hobbits], 'Humans', [Humans], 'Orcs', [Orcs], 'Trolls',[Trolls] , 'Wizzards', [Wizzards], 'Other', [Other]], 'Edit dlc characters', ['The Side Quest Character Pack', [DLC1], 'The Big Little Character Pack', [DLC2]], 'Edit other characters']],
    ['Items', ['Text 1', 'Text 1', 'Text 3']],
    #['Levels', ['Text 1', 'Text 1', 'Text 3']],
    ['View', ['Console', 'Theme']],
    ['Help', ['Change game path', 'I found a bug', 'I need help']],
    ['About', ['<popup here>']]
]
'''
layout_main_original = [
            [sg.Menu(layout_main_bar)],
            [sg.HorizontalSeparator()],  # key=
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(7, 0)), sg.Text('Main:', size=(10, 0)), sg.Text('', size=(30, 0)), sg.Text("DLC's:")],
            [sg.Text('', size=(7, 0)), sg.Button('Unlock Every Character', tooltip='Unlock every playble game character.', size=(30, 1)),
             sg.Text('', size=(7, 0)), sg.Button(' Side Quest Character Pack', size=(30, 1)), sg.Text('', size=(7, 0))],
            # Spacer
            [sg.Text('', size=(7, 0)), sg.Button(' Unlock Every Item', size=(30, 1)), sg.Text('', size=(7, 0)), sg.Button('The Big Little Character Pack', size=(30, 1))],
            [sg.Text('', size=(7, 0)), sg.Button(' Unlock Every Animal', size=(30, 1)), sg.Text('', size=(7, 0)), sg.Button('The Battle Pack', size=(30, 1))],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(7, 0)), sg.Checkbox('Faster Game Loading Time?', k='cutscene-checkbox', enable_events=True)],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(57, 0)), sg.Button('Reset the game to default', size=(20, 0))],
            [sg.Text('', size=(0, 0))],
            [sg.HorizontalSeparator()],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(7, 0)), sg.Text('Edits List:'), sg.Button('Update Multiline [testing]', key='multiline-test-button')],
            [sg.Text('', size=(7, 0)), sg.Multiline(Edits_list, s=(78, 5), disabled=True, key='multiline-edits-log')],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(7, 0)), sg.Button('Apply', size=(8, 1)), sg.Button('Cancel', size=(8, 1)), sg.Button('Exit', size=(8, 1))]
        ]
'''
layout_main = [
            [sg.Menu(layout_main_bar)],
            [sg.HorizontalSeparator()],  # key=
            [sg.Text('', size=(40, 0))],
            [sg.Text('', size=(6, 0)), sg.Frame(layout=[
                [sg.Checkbox('Unlock Every Character', k='UnlockEveryCharacter', tooltip='Unlock every playable game character.', default=collection_unlocked, size=(25, 1))],
                [sg.Checkbox(' Unlock Every Item',   size=(25, 1))],
                [sg.Checkbox(' Unlock Every Animal', size=(25, 1))]],
                title='General', tooltip='general settings'), sg.Text('', size=(9, 0)), sg.Frame(layout=[
                [sg.Checkbox('Side Quest Character Pack',     size=(25, 1))],
                [sg.Checkbox('The Big Little Character Pack', size=(25, 1))],
                [sg.Checkbox('The Battle Pack',               size=(25, 1))]],
                title="DLC's", tooltip='general settings'), sg.Text('', size=(6, 0))],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(7, 0)), sg.Checkbox('Faster Game Loading Time?', k='cutscene-checkbox', default=cutscene_off, enable_events=True)],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(57, 0)), sg.Button('Reset the game to default', size=(20, 0))],
            [sg.Text('', size=(0, 0))],
            [sg.HorizontalSeparator()],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(7, 0)), sg.Text('Edits List:'), sg.Button('Update Multiline [testing]', key='multiline-test-button')],
            [sg.Text('', size=(7, 0)), sg.Multiline(Edits_list, s=(78, 5), disabled=True, key='multiline-edits-log')],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(0, 0))],
            [sg.Text('', size=(7, 0)), sg.Button('Apply', size=(8, 1)), sg.Button('Cancel', size=(8, 1)), sg.Button('Exit', size=(8, 1))]
        ]
layout_popup = [
    [sg.Text('To run the mod, first select the folder in witch the game exec is located.')],
    [sg.Text('(Probably named "LEGO - The Hobbit" )')],
    #[sg.InputText(size=(44, 1)), sg.FileBrowse(key="-IN-", change_submits=True, file_types=(("LEGOHobbit.exe", "*.exe"),))], # For seleceting the .exe
    [sg.InputText(size=(50, 1), k='Input'), sg.FolderBrowse(key="FolderBrowse", change_submits=True)],
    [sg.Text()],
    [sg.Button('Exit', s=(6,1)), sg.Button('Ok', s=(6,1))]
]

edits_testing = [
    ['>  Alfrid --> Scale = 1.4 | Walking speed = 3\n'],
    ['>  Unlocked every character\n']
] # Ignore

# Parameters for characters --------------------------------------------------------------------------------------------
Alfrid_window = True
Bard_window = False
Bilbo_window = False

Alfrid_edited = False # Prob necessary in the future
Bard_edited = False # Prob necessary in the future

# Set window -----------------------------------------------------------------------------------------------------------
window_main = sg.Window('LEGO - The Hobbit', layout=layout_main, margins=(1, 1), alpha_channel=0.9)

# Console
console = win32gui.GetForegroundWindow()
view_console = True

# Main loop
run = True
while run == True:
    while main_window_state == True:
        event, values = window_main.read()
        print(event, values)
        if event is None or event == sg.WIN_CLOSED:
            window_main.close()
            main_window_state = False
            run = False
            sys.exit()
            break
        if event == 'Change game path':
                popup_state = True
                main_window_state = False
        if event == 'Text 1':
                Alfrid = Character('Alfrid')
                Alfrid.char_editor()
                Alfrid_window = True
                while Alfrid_window == True:
                    Alfrid.char_editor_buttons()
                    Alfrid_window = False
        if event == 'Alfrid':
                Alfrid = Character('Alfrid')
                Alfrid.char_editor()
                Alfrid_window = True
                while Alfrid_window == True:
                    Alfrid.char_editor_buttons()
                    Alfrid_window = False
        if event == 'Apply':
            popup = apply_changes()
            if popup.apply == True:
                # Unlock ever
                if values['UnlockEveryCharacter'] == True and collection_unlocked == False:
                    data = open('Files/COLLECTION[unlocked].TXT', 'r').read()
                    my_file = open(game_location_path + '/CHARS/COLLECTION.TXT', 'w')
                    my_file.write(data)
                    my_file.close()
                    print('Unlocked every character!')
                if values['UnlockEveryCharacter'] == False and collection_unlocked == True:
                    data = open('Files/COLLECTION[default].TXT', 'r').read()
                    my_file = open(game_location_path + '/CHARS/COLLECTION.TXT', 'w')
                    my_file.write(data)
                    my_file.close()
                    print('Deunlocked every character!')
                # Cutscene (works!)
                if values['cutscene-checkbox'] == True and cutscene_off == False: # If we want to remove the cutscene and it's is still on
                    cutscene_cut('off')
                    dabadidabada = 'i can hide this now'
                if values['cutscene-checkbox'] == False and cutscene_off == True: # If we want to not remove the cutscene and it's removed
                    cutscene_cut('on')
                    dabadidabada = 'i can hide this now'

                check_COLLECTION_state()
                cutscene_cut('status_check')
        if event == 'Reset the game to default':
            popup = reset_game_files()
            check_COLLECTION_state()
            window_main['UnlockEveryCharacter'].Update(value=collection_unlocked)
        # Toggle console (works only on.exe)
        if event == 'Console':
            view_console = not view_console
            option = win32con.SW_SHOW if view_console else win32con.SW_HIDE
            win32gui.ShowWindow(console, option)

# UPDATE WINDOW ELEMENT (CHECKBOX EXAMPLE) window_main['UnlockEveryCharacter'].Update(value=collection_unlocked)
#pyinstaller --onefile "D:\Aplikacje\Pycharm\Lego The Hobbit Mod [.exe]\main.py"